<html>
<head>
<title>Hello Elastic Beanstalk</title>
</head>
<body>
<h1 align="center">Easy App! This is version 1.0</h1><br>
<div align="center">
<img src="meme2.png">
</div>
</body>
</html>